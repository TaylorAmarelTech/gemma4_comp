DueCare prompt/evaluation/training seed sample

Synthetic prompts, rubric dimensions, SFT pairs, and preference pairs for Harness Comparison and A-00 workflows.
Use as seed material only; generate larger datasets through the harness and review before fine-tuning.
