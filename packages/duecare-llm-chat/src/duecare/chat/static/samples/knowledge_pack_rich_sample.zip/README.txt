DueCare rich knowledge pack sample

Importable sample with matching, grounding, reasoning, evaluation, tool, input, and output knowledge objects.
All entries are synthetic and should be reviewed before production use.
