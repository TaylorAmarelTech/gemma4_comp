DueCare workbench - sample case bundle

This is a fully synthetic, judge-safe bundle for the Process Files
page. All names, employers, and contact details are composite. No
real worker information appears in this archive.

Files in this bundle:

  recruiter_chat_01.txt   - composite WhatsApp/Viber excerpt with
                            placement-fee + passport-retention signals
  recruiter_chat_02.txt   - composite chat with contract-substitution
                            signal and corridor-mismatch hint
  contract_excerpt_01.txt - composite contract clause with debt-bondage
                            and fee-recovery wording
  recruiter_messages.csv  - 5 short messages with mixed signal density

Drop this ZIP onto Process Files to see the GREP layer and entity
extractor light up. Typical output:
  - 9-12 GREP rule hits across the 4 files
  - 6-8 entities extracted (AMOUNT, CORRIDOR, STATUTE)
  - A local knowledge graph you can chat against with Gemma 4

License: MIT. Contents are entirely composite.
