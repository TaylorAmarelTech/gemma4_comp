DueCare Bulk File Review sample case bundle

Fully synthetic PH to HK case-folder bundle for the Gemma 4 Good demo.
It mirrors a realistic local intake folder: each person has text records,
CSV histories, and media-like evidence under a client-style folder path.

Included evidence types:
- recruiter chat transcripts
- complaints and police-style summaries
- ID-card records
- location, travel, and payment CSVs
- PNG screenshots of recruiter chats
- JPEG document photos
- scan-like PDF receipts queued for OCR and Gemma 4 vision

All names, phones, agencies, employers, locations, and amounts are
fictional composites. Not real evidence.
