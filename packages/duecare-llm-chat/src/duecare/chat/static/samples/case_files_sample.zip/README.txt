﻿Synthetic PH to HK case bundle for DueCare Bulk File Review.
Contains 30 synthetic individuals and 210 evidence files across ID card records, complaints, police reports, travel history, location history, payment history, and recruiter chats.
All names, IDs, phones, dates, and facts are artificial.
