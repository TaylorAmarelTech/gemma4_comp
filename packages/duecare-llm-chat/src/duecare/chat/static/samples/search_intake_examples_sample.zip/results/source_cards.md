## Synthetic public-source card: unlicensed employment agency fine

URL: https://example.invalid/hk-employment-agency-fine

Composite source card: a Hong Kong employment-agency enforcement item describes licensing requirements, fines, and refund orders. Use for search-to-knowledge drafting demos.

## Synthetic public-source card: recruitment fee prohibition

URL: https://example.invalid/ilo-c181-worker-fees

Composite source card: ILO private-employment-agency standards prohibit worker-paid recruitment fees, subject to narrow exceptions.

## Synthetic public-source card: passport retention advisory

URL: https://example.invalid/passport-retention-advisory

Composite source card: migrant worker advisory explains that passport retention by employers or recruiters is a document-control risk signal.
