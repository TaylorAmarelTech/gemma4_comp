DueCare Search and Source Intake sample

Offline, synthetic search evidence set for demoing query planning, result review, and search-to-knowledge drafting.
