# Public-record inclusion policy

This sample bundle ships synthetic public-record-like documents only. Real
government publications, judgments, court opinions, labour-department press
releases, and regulator notices can be bundled later when the source record is
matched to explicit public-domain, open-government, court-publication, or
otherwise reusable licensing terms.

Before including an actual public document, add a manifest entry with:
- source URL
- publisher / court / agency
- publication date
- license or public-domain basis
- last_verified_at
- exact file hash
- reason it is useful for the anti-TIP workflow

If that metadata is missing, link the source but do not embed the document.
