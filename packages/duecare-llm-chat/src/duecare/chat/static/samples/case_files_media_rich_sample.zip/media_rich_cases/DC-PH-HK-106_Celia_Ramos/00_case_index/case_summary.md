# Synthetic case folder index

case_id: DC-PH-HK-106
worker_name: Celia Ramos
agency: Eastline Manpower Services
employer: Hong Kong Household MR-006
corridor: PH-HK
origin_city: Makati
destination_area: Yuen Long

Primary allegations in this synthetic packet:
- PHP 74500 in training, medical, processing, and documentation charges
- salary deduction of HKD 2430 after arrival in Hong Kong
- passport retained by employer for "safekeeping"
- warning that complaint filing may affect placement or employer support

Reviewer prompt ideas:
- Which entities appear across the most evidence types?
- Which cases have the strongest fee-overcharge evidence?
- Which files need OCR or Gemma 4 vision before the graph can be trusted?
- Which individuals could be grouped for a pattern or class-style review?
