# Synthetic regulator complaint procedure

Purpose: model a public complaint pathway document without copying a real website.
Fields: agency name, complaint channel, worker-protection note, retaliation warning, last verified date.
