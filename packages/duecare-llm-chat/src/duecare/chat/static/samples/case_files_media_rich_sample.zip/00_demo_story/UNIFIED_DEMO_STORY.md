# Unified PH-HK demo story

This bundle uses one coherent synthetic story across the demo:

- corridor: Philippines to Hong Kong
- sector: domestic work
- primary agency label: Pearl Bridge Manpower
- primary case: DC-PH-HK-101 / Ana Cruz
- recurring pattern: worker-paid training, medical, processing, and documentation package
- post-arrival mechanism: salary deduction in Hong Kong
- control signals: passport safekeeping language, complaint-retaliation pressure, folder-derived case labels

Use the same story when recording Compare, Bulk File Review, Knowledge
Extraction, Search intake, Anonymization & Sharing, and A-00 synthetic
training. The names, IDs, accounts, receipts, and documents are fictional.
