# Expected outputs for the media-rich sample

These fixtures are not the model answer. They are a stable reference for
judge/demo testing so a reviewer can compare graph-chat answers against the
synthetic evidence structure.

The uploaded graph should be able to answer:
- which entities are associated with the largest fee amounts
- which individuals have the strongest evidence package
- which row paths support salary deduction and passport retention
- which records are clean, borderline, or false-positive calibration cases

All cases and entities are synthetic.
