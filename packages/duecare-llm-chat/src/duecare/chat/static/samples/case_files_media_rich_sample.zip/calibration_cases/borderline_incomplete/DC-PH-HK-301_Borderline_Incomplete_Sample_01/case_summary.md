# Calibration case

case_id: DC-PH-HK-301
label: borderline_incomplete
name: Borderline Incomplete Sample 01
agency: Unclear Training Provider
fee_php: 8500
deduction_hkd: 0
expected_interpretation: training payment mentioned but payer and statutory category unclear

Use these cases to test specificity. The harness should not treat every
amount, passport word, or salary-deduction phrase as trafficking evidence.
