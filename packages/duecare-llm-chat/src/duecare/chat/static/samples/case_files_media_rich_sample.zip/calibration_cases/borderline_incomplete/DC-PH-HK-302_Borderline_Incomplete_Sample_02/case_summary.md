# Calibration case

case_id: DC-PH-HK-302
label: borderline_incomplete
name: Borderline Incomplete Sample 02
agency: Ambiguous Support Office
fee_php: 12000
deduction_hkd: 0
expected_interpretation: receipt exists but relationship to recruitment is unclear

Use these cases to test specificity. The harness should not treat every
amount, passport word, or salary-deduction phrase as trafficking evidence.
