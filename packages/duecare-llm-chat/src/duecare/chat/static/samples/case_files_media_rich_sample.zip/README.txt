DueCare Bulk File Review - media-rich sample bundle

Fully synthetic PH to HK intake packet designed to look like a real local case
folder without using real people, real IDs, real chat accounts, or real evidence.

This smaller bundle is for demoing upload review. Each case includes:
- plain-text chat export
- Facebook Messenger-style screenshot PNG
- WhatsApp-style screenshot PNG
- receipt photo JPEG
- passport / ID-page photo JPG
- contract or side-letter photo JPG
- worker intake DOCX
- extractable PDF contract excerpt
- scan-like PDF receipt queued for OCR and Gemma 4 vision
- legacy DOC/RTF case note
- EML handoff email
- XLSX payment schedule
- CSV travel/location timeline
- caseworker review notes
- HTML/MBOX/WhatsApp export examples
- TIFF/WEBP/HEIC-format media inventory examples
- nested ZIP export from a phone backup
- OPUS/M4A voice-note placeholders
- clean, borderline, and false-positive calibration folders
- expected-output fixtures for graph-chat testing
- synthetic public-record shapes for court, regulator, and press-release material
- a few queued binary Office artifacts to show inventory handling

All content is fictional and composite. Use this when a judge asks whether the
bulk review page can handle the messy folder shape NGOs and caseworkers see.

The synthetic form shapes are modeled around public PH-HK domestic-worker
materials, without bundling or copying official PDFs:
- Hong Kong Immigration Department ID 407 standard employment contract page
- Hong Kong Immigration Department ID 407G accommodation/duties schedule page
- Hong Kong Labour Department Employment Agencies Portal fee guidance
- Hong Kong FDH portal FAQ on agency commission, passports, and loans
- Philippine DMW/POEA memorandum circular archive pages
