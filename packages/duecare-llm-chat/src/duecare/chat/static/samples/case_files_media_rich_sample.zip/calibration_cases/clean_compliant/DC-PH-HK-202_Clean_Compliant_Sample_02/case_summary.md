# Calibration case

case_id: DC-PH-HK-202
label: clean_compliant
name: Clean Compliant Sample 02
agency: Clear Contract Placement
fee_php: 0
deduction_hkd: 0
expected_interpretation: written no-fee confirmation; passport-return clause; rest-day terms

Use these cases to test specificity. The harness should not treat every
amount, passport word, or salary-deduction phrase as trafficking evidence.
