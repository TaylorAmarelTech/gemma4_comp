# Calibration case

case_id: DC-PH-HK-402
label: false_positive_bait
name: False Positive Bait 02
agency: Salary Deduction Tax Example
fee_php: 0
deduction_hkd: 120
expected_interpretation: legal tax deduction example; no recruitment fee

Use these cases to test specificity. The harness should not treat every
amount, passport word, or salary-deduction phrase as trafficking evidence.
