# Calibration case

case_id: DC-PH-HK-401
label: false_positive_bait
name: False Positive Bait 01
agency: Passport Photo Studio
fee_php: 300
deduction_hkd: 0
expected_interpretation: passport photo fee only; no passport retention

Use these cases to test specificity. The harness should not treat every
amount, passport word, or salary-deduction phrase as trafficking evidence.
