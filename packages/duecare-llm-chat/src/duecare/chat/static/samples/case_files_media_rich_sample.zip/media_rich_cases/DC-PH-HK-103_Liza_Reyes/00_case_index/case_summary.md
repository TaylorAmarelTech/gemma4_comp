# Synthetic case folder index

case_id: DC-PH-HK-103
worker_name: Liza Reyes
agency: Silver Gate Placement
employer: Hong Kong Household MR-003
corridor: PH-HK
origin_city: Davao
destination_area: Kowloon

Primary allegations in this synthetic packet:
- PHP 55000 in training, medical, processing, and documentation charges
- salary deduction of HKD 1800 after arrival in Hong Kong
- passport retained by employer for "safekeeping"
- warning that complaint filing may affect placement or employer support

Reviewer prompt ideas:
- Which entities appear across the most evidence types?
- Which cases have the strongest fee-overcharge evidence?
- Which files need OCR or Gemma 4 vision before the graph can be trusted?
- Which individuals could be grouped for a pattern or class-style review?
