# Calibration case

case_id: DC-PH-HK-201
label: clean_compliant
name: Clean Compliant Sample 01
agency: Compliant Pathways Agency
fee_php: 0
deduction_hkd: 0
expected_interpretation: employer-paid recruitment; worker keeps passport; no deductions

Use these cases to test specificity. The harness should not treat every
amount, passport word, or salary-deduction phrase as trafficking evidence.
