# Synthetic case folder index

case_id: DC-PH-HK-101
worker_name: Ana Cruz
agency: Pearl Bridge Manpower
employer: Hong Kong Household MR-001
corridor: PH-HK
origin_city: Manila
destination_area: Causeway Bay

Primary allegations in this synthetic packet:
- PHP 42000 in training, medical, processing, and documentation charges
- salary deduction of HKD 1380 after arrival in Hong Kong
- passport retained by employer for "safekeeping"
- warning that complaint filing may affect placement or employer support

Reviewer prompt ideas:
- Which entities appear across the most evidence types?
- Which cases have the strongest fee-overcharge evidence?
- Which files need OCR or Gemma 4 vision before the graph can be trusted?
- Which individuals could be grouped for a pattern or class-style review?
