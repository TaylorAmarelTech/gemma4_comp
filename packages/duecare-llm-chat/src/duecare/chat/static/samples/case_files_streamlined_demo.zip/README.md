# DueCare streamlined Bulk File Review demo

This is a five-document, fully synthetic PH-HK domestic-worker case
designed for a short live demo. It is intentionally small so reviewers can
see the full path clearly:

1. Upload ZIP
2. Watch local processing progress
3. Inspect people, payments, journey stages, and graph edges
4. Optionally run the local Gemma 4 edge pass
5. Ask conversational questions against the confirmed graph

No real worker information appears in this archive.
