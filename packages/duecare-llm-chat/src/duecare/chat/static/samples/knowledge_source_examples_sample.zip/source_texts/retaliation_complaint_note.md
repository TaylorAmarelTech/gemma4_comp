# Synthetic complaint note

The worker asked whether she could file a complaint. The recruiter warned that the employer would be informed and might stop supporting the placement. Draft knowledge should capture retaliation-risk warnings and safe referral boundaries.
