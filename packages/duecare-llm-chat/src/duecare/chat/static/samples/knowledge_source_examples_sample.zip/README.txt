DueCare knowledge-source upload examples

Synthetic raw source materials for /static/knowledge.html Step 1. Upload this ZIP to draft knowledge-object suggestions from mixed source text and media placeholders.
