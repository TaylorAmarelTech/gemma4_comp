# DueCare knowledge files sample

This ZIP is intentionally named as knowledge files because it contains existing knowledge-object envelopes, not raw case files. Use it on Knowledge Extraction Step 3, Sync, or Anonymization & Sharing when you want a maintained pack of reusable rules, citations, reasoning snippets, tool definitions, rubrics, and non-PII facts.

Importable entries follow `<knowledge_object_type>/<id>.json`. Root README/manifest files are informational metadata.
