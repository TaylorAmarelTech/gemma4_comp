DueCare workbench - sample knowledge bundle

Four sample knowledge envelopes spanning distinct leaf types. ZIP
entries are pathed as `<type>/<id>.json` so that /api/knowledge/import
accepts the bundle directly.

  grep_rule/sample-passport-retention-v1.json
  rag_doc/sample-ilo-c181.json
  context_snippet/sample-placement-fee-cap.json
  rubric_dimension/sample-contract-substitution.json

Drop this ZIP onto the Knowledge Extraction page (or onto Sync ->
Manual upload) to import all four at once. After import:
  - the GREP rule is live in the matching layer
  - the rag_doc is searchable by RAG
  - the context_snippet is available as reasoning grounding
  - the rubric_dimension lights up in grade-deep / grade-combined

All payloads are composite and judge-safe.
License: MIT.
