"""In-process task queue with separate GPU + CPU worker pools.

Why in-process: a Kaggle notebook is single-machine; one process owns
the GPU (and the loaded Gemma 4 weights) for the duration of the
session. We don't want a Redis hop, a Celery worker, or a second
Python process. Threads + queue.Queue is enough.

Why GPU + CPU pools: GPU work serialises on a single Gemma 4 instance
(loading two would OOM). CPU-bound work (template SQL, regex
moderation, evidence-DB ingestion) runs in parallel.

Usage
-----
    from duecare.server.task_queue import TaskQueue
    q = TaskQueue(gpu_workers=1, cpu_workers=4)

    def handle_classify(payload: dict) -> dict:
        return state.gemma_call(payload["text"], 200)
    q.register("gemma_classify", handle_classify, gpu=True)

    task_id = q.submit("gemma_classify", {"text": "..."})
    # poll: q.get(task_id).status / .result
"""
from __future__ import annotations

import logging
import queue
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Optional


log = logging.getLogger(__name__)


@dataclass
class Task:
    task_id: str
    task_type: str
    payload: dict
    gpu: bool = False
    status: str = "pending"            # pending|running|completed|failed
    submitted_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Any = None
    error: Optional[str] = None
    runtime_seconds: Optional[float] = None

    def as_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "task_type": self.task_type,
            "payload": self.payload,
            "gpu": self.gpu,
            "status": self.status,
            "submitted_at": self.submitted_at.isoformat(),
            "started_at": (self.started_at.isoformat()
                            if self.started_at else None),
            "completed_at": (self.completed_at.isoformat()
                              if self.completed_at else None),
            "result": self.result,
            "error": self.error,
            "runtime_seconds": self.runtime_seconds,
        }


class TaskQueue:
    """Two-pool task queue. GPU pool serialises Gemma calls; CPU pool
    runs everything else in parallel."""

    def __init__(self, gpu_workers: int = 1,
                  cpu_workers: int = 4,
                  max_history: int = 1000):
        self.tasks: dict[str, Task] = {}
        self.gpu_q: queue.Queue = queue.Queue()
        self.cpu_q: queue.Queue = queue.Queue()
        # task_type -> (handler, requires_gpu)
        self.handlers: dict[str, tuple[Callable, bool]] = {}
        self.max_history = max_history
        self._stop = threading.Event()
        self._workers: list[threading.Thread] = []
        self._lock = threading.Lock()
        for i in range(max(1, gpu_workers)):
            t = threading.Thread(
                target=self._worker_loop,
                args=(self.gpu_q, f"gpu-{i}"),
                daemon=True, name=f"duecare-gpu-{i}")
            t.start()
            self._workers.append(t)
        for i in range(max(1, cpu_workers)):
            t = threading.Thread(
                target=self._worker_loop,
                args=(self.cpu_q, f"cpu-{i}"),
                daemon=True, name=f"duecare-cpu-{i}")
            t.start()
            self._workers.append(t)
        log.info("TaskQueue started: %d GPU + %d CPU workers",
                  gpu_workers, cpu_workers)

    # -- registration --------------------------------------------------------
    def register(self, task_type: str, handler: Callable,
                  gpu: bool = False) -> None:
        """Register a handler. `handler(payload: dict) -> Any`."""
        self.handlers[task_type] = (handler, gpu)
        log.info("registered task type %r (gpu=%s)", task_type, gpu)

    def known_task_types(self) -> list[str]:
        return sorted(self.handlers.keys())

    # -- submit / poll -------------------------------------------------------
    def submit(self, task_type: str, payload: dict) -> str:
        if task_type not in self.handlers:
            raise ValueError(
                f"unknown task type: {task_type!r}. "
                f"Known: {self.known_task_types()}")
        _handler, gpu = self.handlers[task_type]
        task_id = f"task_{uuid.uuid4().hex[:12]}"
        task = Task(task_id=task_id, task_type=task_type,
                     payload=payload or {}, gpu=gpu)
        with self._lock:
            self.tasks[task_id] = task
            self._evict_old()
        target = self.gpu_q if gpu else self.cpu_q
        target.put(task)
        return task_id

    def get(self, task_id: str) -> Optional[Task]:
        with self._lock:
            return self.tasks.get(task_id)

    def list(self, limit: int = 100,
              status: Optional[str] = None) -> list[Task]:
        with self._lock:
            items = sorted(self.tasks.values(),
                            key=lambda t: t.submitted_at,
                            reverse=True)
        if status:
            items = [t for t in items if t.status == status]
        return items[:limit]

    def stats(self) -> dict:
        with self._lock:
            counts = {"pending": 0, "running": 0,
                       "completed": 0, "failed": 0}
            for t in self.tasks.values():
                counts[t.status] = counts.get(t.status, 0) + 1
            return {
                "total": len(self.tasks),
                "by_status": counts,
                "gpu_qsize": self.gpu_q.qsize(),
                "cpu_qsize": self.cpu_q.qsize(),
                "registered_handlers": self.known_task_types(),
            }

    def shutdown(self, timeout: float = 5.0) -> None:
        self._stop.set()
        deadline = time.time() + timeout
        for w in self._workers:
            remaining = max(0.0, deadline - time.time())
            w.join(timeout=remaining)

    # -- internals -----------------------------------------------------------
    def _worker_loop(self, q: queue.Queue, worker_name: str) -> None:
        while not self._stop.is_set():
            try:
                task = q.get(timeout=1.0)
            except queue.Empty:
                continue
            handler_entry = self.handlers.get(task.task_type)
            if handler_entry is None:
                task.status = "failed"
                task.error = f"handler vanished for {task.task_type}"
                task.completed_at = datetime.now()
                q.task_done()
                continue
            handler, _ = handler_entry
            task.status = "running"
            task.started_at = datetime.now()
            try:
                task.result = handler(task.payload)
                task.status = "completed"
            except Exception as e:
                task.error = f"{type(e).__name__}: {e}"
                task.status = "failed"
                log.exception("[%s] task %s FAILED",
                                worker_name, task.task_id)
            task.completed_at = datetime.now()
            if task.started_at:
                task.runtime_seconds = (
                    task.completed_at - task.started_at).total_seconds()
            q.task_done()

    def _evict_old(self) -> None:
        """Cap task history to max_history (drop oldest completed/failed)."""
        if len(self.tasks) <= self.max_history:
            return
        finished = [t for t in self.tasks.values()
                    if t.status in ("completed", "failed")]
        finished.sort(key=lambda t: t.completed_at or t.submitted_at)
        for t in finished[:len(self.tasks) - self.max_history]:
            self.tasks.pop(t.task_id, None)
