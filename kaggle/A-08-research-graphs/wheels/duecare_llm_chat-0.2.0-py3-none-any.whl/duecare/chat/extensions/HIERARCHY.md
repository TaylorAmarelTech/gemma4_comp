# HIERARCHY — `duecare.chat.extensions`

## Parent

`duecare.chat`

## Siblings

- `harness`

## Children

_(none)_

## Depends on

`duecare.core` (contracts, schemas) — and any cross-package imports listed in this module's `pyproject.toml` dependencies.

## Depended on by

See the workspace dependency graph in `docs/architecture.md`.
