"""Shared quantitative experiment contracts for DueCare notebooks.

These constants keep comparison, synthetic-data, and fine-tune smoke paths
portable across Kernel 01, A-00, A-07, and the live-demo notebooks. Notebook
code may still provide bootstrapping fallbacks before the wheel is installed,
but successful runs should read these contracts rather than restating magic
numbers inline.
"""
from __future__ import annotations

from typing import Any


GENERATION_DEFAULTS: dict[str, Any] = {
    "temperature": 0.2,
    "top_p": 0.95,
    "top_k": 64,
    "max_new_tokens": 420,
    "evaluate": True,
    "llm_judge": False,
}

HARNESS_PROFILES: tuple[dict[str, Any], ...] = (
    {
        "id": "none",
        "label": "No harness",
        "layers": [],
        "description": "Plain model call. Use as the baseline.",
    },
    {
        "id": "chat_full",
        "label": "Chat safety harness",
        "layers": ["persona", "grep", "rag", "tools", "online"],
        "description": "Primary chat harness with all safety layers enabled.",
    },
    {
        "id": "chat_no_online",
        "label": "Chat offline harness",
        "layers": ["persona", "grep", "rag", "tools"],
        "description": "Local-first chat harness without third-party search.",
    },
    {
        "id": "process",
        "label": "Bulk File Review",
        "layers": ["grep", "rag", "tools"],
        "description": "Bundle-processing harness for case files and graph evidence.",
    },
    {
        "id": "extraction",
        "label": "Knowledge extraction",
        "layers": ["grep", "rag"],
        "description": "Draft typed knowledge objects from source bundles or raw text.",
    },
    {
        "id": "anonymization",
        "label": "Anonymization gate",
        "layers": ["privacy_gate"],
        "description": "Redact PII before any external boundary.",
    },
    {
        "id": "search_safety",
        "label": "Search safety gate",
        "layers": ["privacy_gate", "query_rewrite"],
        "description": "Sanitize outbound search queries before third-party search.",
    },
    {
        "id": "search",
        "label": "Search utility",
        "layers": [],
        "description": "Utility search surface. Pair with search safety for privacy.",
    },
    {
        "id": "import_corpus",
        "label": "Import corpus utility",
        "layers": [],
        "description": "Evidence CRUD surface with audit metadata. No Gemma call required.",
    },
)

QUANTITATIVE_RUN_PROFILES: tuple[dict[str, Any], ...] = (
    {
        "id": "bulk_text_25",
        "label": "Bulk text harness comparison",
        "purpose": "Today's default: run the same 25 text prompts with and without the chat harness and generate a report.",
        "prompt_set": "chat_safety_core",
        "limit": 25,
        "baseline_harness": "none",
        "treatment_harness": "chat_full",
        "generation": dict(GENERATION_DEFAULTS),
        "report_title": "DueCare harness lift: Gemma 4 stock vs stock+harness",
    },
    {
        "id": "bulk_text_50",
        "label": "Larger text harness comparison",
        "purpose": "Use when runtime allows a stronger 50-prompt comparison before recording.",
        "prompt_set": "chat_safety_120",
        "limit": 50,
        "baseline_harness": "none",
        "treatment_harness": "chat_full",
        "generation": dict(GENERATION_DEFAULTS),
        "report_title": "DueCare harness lift: 50-prompt text regression",
    },
    {
        "id": "tiny_lora_smoke",
        "label": "Tiny LoRA smoke comparison",
        "purpose": "Generate a small SFT/DPO bundle, create or run a tiny LoRA, then compare four arms.",
        "prompt_set": "chat_safety_core",
        "limit": 20,
        "synthetic_count": 24,
        "synthetic_profile": "rubric_polisher_24",
        "training_profile": "tiny_lora_smoke",
        "comparison_matrix": "stock_vs_finetuned_harness_matrix",
        "generation": dict(GENERATION_DEFAULTS),
    },
)

SYNTHETIC_GENERATION_PROFILES: tuple[dict[str, Any], ...] = (
    {
        "id": "rubric_polisher_24",
        "label": "Rubric-polished SFT/DPO smoke seed",
        "source_prompt_set": "synthetic_seed",
        "count": 24,
        "harness_profile": "chat_full",
        "generator_mode": "rubric_polisher",
        "include_dpo": True,
        "include_knowledge_facts": True,
        "temperature": 0.7,
    },
    {
        "id": "harness_teacher_40",
        "label": "Harness-teacher synthetic training seed",
        "source_prompt_set": "synthetic_seed",
        "count": 40,
        "harness_profile": "chat_full",
        "generator_mode": "harness_teacher",
        "include_dpo": True,
        "include_knowledge_facts": True,
        "temperature": 0.7,
    },
)

TRAINING_PROFILES: tuple[dict[str, Any], ...] = (
    {
        "id": "tiny_lora_smoke",
        "label": "Tiny LoRA smoke run",
        "base_model_ref": "google/gemma-4-e2b-it",
        "adapter_name": "duecare-a00-smoke-e2b-lora",
        "method": "sft",
        "execute": False,
        "max_steps": 60,
        "learning_rate": 2e-4,
        "max_seq_length": 4096,
        "per_device_train_batch_size": 1,
        "gradient_accumulation_steps": 8,
        "warmup_steps": 5,
        "lora_r": 16,
        "lora_alpha": 16,
        "lora_dropout": 0.0,
        "random_state": 3407,
        "target_modules": ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    },
    {
        "id": "a07_t4_standard_sft",
        "label": "A-07 T4 standard SFT",
        "base_model_ref": "google/gemma-4-e4b-it",
        "max_examples": 200,
        "num_epochs": 2,
        "learning_rate": 2e-4,
        "per_device_train_batch_size": 2,
        "gradient_accumulation_steps": 4,
        "warmup_ratio": 0.03,
        "lora_r": 16,
        "lora_alpha": 32,
        "lora_dropout": 0.05,
        "max_seq_length": 4096,
    },
    {
        "id": "a07_t4_standard_dpo",
        "label": "A-07 T4 standard DPO",
        "max_pairs": 100,
        "num_epochs": 1,
        "learning_rate": 5e-6,
        "per_device_train_batch_size": 1,
        "gradient_accumulation_steps": 4,
        "beta": 0.1,
    },
)

UPLOAD_LIMITS: dict[str, int] = {
    "max_jsonl_rows": 20_000,
    "max_text_chars": 20_000,
    "max_zip_bytes": 200_000_000,
    "max_jsonl_bytes": 200_000_000,
    "max_jsonl_line_chars": 200_000,
    "max_member_bytes": 100_000_000,
    "max_uncompressed_bytes": 500_000_000,
    "max_upload_files": 8,
}

COMPARISON_MATRICES: tuple[dict[str, Any], ...] = (
    {
        "id": "stock_vs_finetuned_harness_matrix",
        "label": "Stock vs fine-tuned vs harness matrix",
        "arms": [
            {"id": "stock", "model_kind": "stock", "harness_profile": "none"},
            {"id": "stock_harness", "model_kind": "stock", "harness_profile": "chat_full"},
            {"id": "finetuned", "model_kind": "finetuned", "harness_profile": "none"},
            {"id": "finetuned_harness", "model_kind": "finetuned", "harness_profile": "chat_full"},
        ],
        "primary_metrics": [
            "mean_score_pct",
            "dimension_lift_pp",
            "unsafe_fail_rate",
            "citation_grounding_rate",
            "mean_seconds",
        ],
    },
)


def harness_profile_map() -> dict[str, dict[str, Any]]:
    return {str(item["id"]): {k: v for k, v in item.items() if k != "id"} for item in HARNESS_PROFILES}


def quantitative_run_profile_map() -> dict[str, dict[str, Any]]:
    return {str(item["id"]): dict(item) for item in QUANTITATIVE_RUN_PROFILES}


def synthetic_generation_profile_map() -> dict[str, dict[str, Any]]:
    return {str(item["id"]): dict(item) for item in SYNTHETIC_GENERATION_PROFILES}


def training_profile_map() -> dict[str, dict[str, Any]]:
    return {str(item["id"]): dict(item) for item in TRAINING_PROFILES}


def upload_limit_map() -> dict[str, int]:
    return dict(UPLOAD_LIMITS)


def comparison_matrix_map() -> dict[str, dict[str, Any]]:
    return {str(item["id"]): dict(item) for item in COMPARISON_MATRICES}


def model_preset_list(model_variants: dict[str, dict[str, Any]]) -> list[dict[str, str]]:
    keys = ["e2b-it", "e4b-it", "26b-a4b-it", "31b-it", "jailbroken-e4b"]
    return [
        {
            "label": model_variants[key]["label"],
            "ref": model_variants[key].get("google_hf_id") or model_variants[key]["hf_id"],
            "source": "hf",
            "notes": model_variants[key]["fit"],
        }
        for key in keys
        if key in model_variants
    ]


def experiment_contract_payload() -> dict[str, Any]:
    return {
        "schema_version": "duecare.experiment_contract.v1",
        "generation_defaults": dict(GENERATION_DEFAULTS),
        "harness_profiles": harness_profile_map(),
        "quantitative_run_profiles": quantitative_run_profile_map(),
        "synthetic_generation_profiles": synthetic_generation_profile_map(),
        "training_profiles": training_profile_map(),
        "upload_limits": upload_limit_map(),
        "comparison_matrices": comparison_matrix_map(),
    }
