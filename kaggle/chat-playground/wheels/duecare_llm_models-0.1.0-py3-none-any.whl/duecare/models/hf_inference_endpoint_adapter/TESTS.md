# Tests — HF Inference Endpoint Adapter

## Run tests for this module only

```bash
# via forge CLI (preferred):
duecare test src/forge/models/hf_inference_endpoint_adapter

# or directly via pytest:
pytest src/forge/models/hf_inference_endpoint_adapter/tests/ -v
```

## Run tests for this module plus all children

```bash
duecare test src/forge/models/hf_inference_endpoint_adapter --recursive
```

## Test files

- `tests/test_adapter.py`

## What each test validates

(Fill in as tests are written.)

## Integration tests that pull in this module

Run `duecare dependents src/forge/models/hf_inference_endpoint_adapter` to find modules that depend on
this one; their tests will exercise this module via their own flows.
