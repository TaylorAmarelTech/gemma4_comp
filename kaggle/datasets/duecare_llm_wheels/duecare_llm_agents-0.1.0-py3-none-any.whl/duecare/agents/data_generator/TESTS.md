# Tests — DataGenerator Agent

## Run tests for this module only

```bash
# via forge CLI (preferred):
duecare test src/forge/agents/data_generator

# or directly via pytest:
pytest src/forge/agents/data_generator/tests/ -v
```

## Run tests for this module plus all children

```bash
duecare test src/forge/agents/data_generator --recursive
```

## Test files

- `tests/test_data_generator.py`

## What each test validates

(Fill in as tests are written.)

## Integration tests that pull in this module

Run `duecare dependents src/forge/agents/data_generator` to find modules that depend on
this one; their tests will exercise this module via their own flows.
